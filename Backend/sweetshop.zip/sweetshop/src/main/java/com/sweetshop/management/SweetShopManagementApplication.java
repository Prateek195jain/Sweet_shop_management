package com.sweetshop.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SweetShopManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SweetShopManagementApplication.class, args);
	}

}
