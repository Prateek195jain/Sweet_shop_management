package com.sweetshop.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SweetShopManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
